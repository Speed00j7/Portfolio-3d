// Wait for the DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Loading screen
    setTimeout(function() {
        const loadingScreen = document.querySelector('.bat-loading-screen');
        if (loadingScreen) {
            loadingScreen.style.opacity = '0';
            setTimeout(function() {
                loadingScreen.style.display = 'none';
            }, 500);
        }
    }, 2000);

    // Navbar scroll effect
    const navbar = document.querySelector('.bat-navbar');
    window.addEventListener('scroll', function() {
        if (window.scrollY > 50) {
            navbar.classList.add('navbar-scrolled');
        } else {
            navbar.classList.remove('navbar-scrolled');
        }
    });

    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 70,
                    behavior: 'smooth'
                });
                
                // Close mobile menu if open
                const navbarToggler = document.querySelector('.navbar-toggler');
                const navbarCollapse = document.querySelector('.navbar-collapse');
                if (navbarCollapse.classList.contains('show')) {
                    navbarToggler.click();
                }
            }
        });
    });

    // Create particle background canvas dynamically
    createParticleBackground();
    
    // Create spider web canvas dynamically
    createSpiderWebBackground();
    
    // Animate elements on scroll
    const animateElements = document.querySelectorAll('.animate-on-scroll');
    
    function checkScroll() {
        const triggerBottom = window.innerHeight * 0.8;
        
        animateElements.forEach(element => {
            const elementTop = element.getBoundingClientRect().top;
            
            if (elementTop < triggerBottom) {
                element.classList.add('animated');
            }
        });
    }
    
    window.addEventListener('scroll', checkScroll);
    checkScroll(); // Check on initial load
    
    // Typing effect for hero title
    const heroTitle = document.querySelector('.bat-hero-title');
    if (heroTitle) {
        const text = heroTitle.textContent;
        heroTitle.textContent = '';
        
        let i = 0;
        function typeWriter() {
            if (i < text.length) {
                heroTitle.textContent += text.charAt(i);
                i++;
                setTimeout(typeWriter, 100);
            }
        }
        
        setTimeout(typeWriter, 2500); // Start after loading screen
    }
    
    // Progress bar animation
    const progressBars = document.querySelectorAll('.bat-skill-progress-bar');
    
    function animateProgressBars() {
        progressBars.forEach(bar => {
            const value = bar.getAttribute('data-width');
            setTimeout(() => {
                bar.style.width = value + '%';
            }, 300);
        });
    }
    
    // Circular progress animation
    const circularProgressBars = document.querySelectorAll('.circle-progress');
    
    function animateCircularProgress() {
        circularProgressBars.forEach(circle => {
            const value = circle.getAttribute('data-percentage');
            const radius = circle.r.baseVal.value;
            const circumference = 2 * Math.PI * radius;
            
            circle.style.strokeDasharray = circumference;
            setTimeout(() => {
                circle.style.strokeDashoffset = circumference - (value / 100) * circumference;
            }, 600);
        });
    }
    
    // Skills section loading effect
    function addSkillsLoadingEffect() {
        const skillCards = document.querySelectorAll('.bat-skill-card');
        
        skillCards.forEach((card, index) => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(50px)';
            card.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
            card.style.transitionDelay = (index * 0.1) + 's';
        });
    }
    
    function showSkillCards() {
        const skillCards = document.querySelectorAll('.bat-skill-card');
        
        skillCards.forEach(card => {
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        });
    }
    
    // Initialize the loading effect
    addSkillsLoadingEffect();
    
    // Intersection Observer for animations
    const observer = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                if (entry.target.classList.contains('bat-skills-section')) {
                    showSkillCards();
                    animateProgressBars();
                    animateCircularProgress();
                }
                entry.target.classList.add('in-view');
            }
        });
    }, { threshold: 0.1 });
    
    document.querySelectorAll('section').forEach(section => {
        observer.observe(section);
    });
    
    // Form validation
    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            let valid = true;
            const inputs = contactForm.querySelectorAll('input, textarea');
            
            inputs.forEach(input => {
                if (input.hasAttribute('required') && !input.value.trim()) {
                    valid = false;
                    input.classList.add('is-invalid');
                } else {
                    input.classList.remove('is-invalid');
                }
                
                if (input.type === 'email' && input.value.trim()) {
                    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                    if (!emailRegex.test(input.value.trim())) {
                        valid = false;
                        input.classList.add('is-invalid');
                    }
                }
            });
            
            if (!valid) {
                e.preventDefault();
            }
        });
        
        // Remove invalid class on input
        contactForm.querySelectorAll('input, textarea').forEach(input => {
            input.addEventListener('input', function() {
                this.classList.remove('is-invalid');
            });
        });
    }
});

// Function to create particle background
function createParticleBackground() {
    // Create canvas element for particles
    const particlesCanvas = document.createElement('canvas');
    particlesCanvas.id = 'particles-js';
    particlesCanvas.className = 'bat-particles-background';
    document.body.insertBefore(particlesCanvas, document.body.firstChild);
    
    const ctx = particlesCanvas.getContext('2d');
    let particles = [];
    const particleCount = 15; // Reduced count for sparse effect
    
    // Set canvas size
    function resizeCanvas() {
        particlesCanvas.width = window.innerWidth;
        particlesCanvas.height = window.innerHeight;
    }
    
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);
    
    // Create particles
    function createParticles() {
        particles = [];
        for (let i = 0; i < particleCount; i++) {
            particles.push({
                x: Math.random() * particlesCanvas.width,
                y: Math.random() * particlesCanvas.height,
                radius: Math.random() * 1.5 + 0.5, // Smaller radius for subtle dots
                color: `rgba(0, ${Math.floor(Math.random() * 100) + 155}, ${Math.floor(Math.random() * 55) + 200}, ${Math.random() * 0.3 + 0.2})`, // Cyan/blue colors
                speedX: Math.random() * 0.3 - 0.15, // Slower movement
                speedY: Math.random() * 0.3 - 0.15,
                pulse: 0,
                pulseSpeed: 0.02 + Math.random() * 0.03 // For glowing effect
            });
        }
    }
    
    createParticles();
    
    // Draw particles
    function drawParticles() {
        ctx.clearRect(0, 0, particlesCanvas.width, particlesCanvas.height);
        
        particles.forEach(particle => {
            // Update pulse for glowing effect
            particle.pulse += particle.pulseSpeed;
            if (particle.pulse > 1 || particle.pulse < 0) {
                particle.pulseSpeed = -particle.pulseSpeed;
            }
            
            // Draw glow effect
            const glow = particle.radius * (1 + particle.pulse);
            const gradient = ctx.createRadialGradient(
                particle.x, particle.y, 0,
                particle.x, particle.y, glow * 3
            );
            gradient.addColorStop(0, particle.color);
            gradient.addColorStop(1, 'rgba(0, 0, 0, 0)');
            
            ctx.beginPath();
            ctx.arc(particle.x, particle.y, glow * 3, 0, Math.PI * 2);
            ctx.fillStyle = gradient;
            ctx.fill();
            
            // Draw particle
            ctx.beginPath();
            ctx.arc(particle.x, particle.y, particle.radius, 0, Math.PI * 2);
            ctx.fillStyle = particle.color.replace(/[^,]+(?=\))/, '1'); // Full opacity for center
            ctx.fill();
            
            // Update position
            particle.x += particle.speedX;
            particle.y += particle.speedY;
            
            // Wrap around edges instead of bouncing
            if (particle.x < 0) particle.x = particlesCanvas.width;
            if (particle.x > particlesCanvas.width) particle.x = 0;
            if (particle.y < 0) particle.y = particlesCanvas.height;
            if (particle.y > particlesCanvas.height) particle.y = 0;
        });
        
        // Draw connections - very subtle, almost invisible
        particles.forEach((particle, i) => {
            particles.slice(i + 1).forEach(otherParticle => {
                const dx = particle.x - otherParticle.x;
                const dy = particle.y - otherParticle.y;
                const distance = Math.sqrt(dx * dx + dy * dy);
                
                if (distance < 200) {
                    ctx.beginPath();
                    ctx.strokeStyle = `rgba(0, 200, 255, ${0.03 * (1 - distance / 200)})`;
                    ctx.lineWidth = 0.3;
                    ctx.moveTo(particle.x, particle.y);
                    ctx.lineTo(otherParticle.x, otherParticle.y);
                    ctx.stroke();
                }
            });
        });
        
        requestAnimationFrame(drawParticles);
    }
    
    drawParticles();
}

// Function to create spider web background
function createSpiderWebBackground() {
    // Create canvas element for spider web
    const webCanvas = document.createElement('canvas');
    webCanvas.id = 'spider-web';
    webCanvas.className = 'bat-web';
    document.body.insertBefore(webCanvas, document.body.firstChild);
    
    const ctx = webCanvas.getContext('2d');
    let points = [];
    const pointCount = 20;
    
    // Set canvas size
    function resizeCanvas() {
        webCanvas.width = window.innerWidth;
        webCanvas.height = window.innerHeight;
    }
    
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);
    
    // Create points
    function createPoints() {
        points = [];
        for (let i = 0; i < pointCount; i++) {
            points.push({
                x: Math.random() * webCanvas.width,
                y: Math.random() * webCanvas.height,
                speedX: Math.random() * 0.5 - 0.25,
                speedY: Math.random() * 0.5 - 0.25
            });
        }
    }
    
    createPoints();
    
    // Draw web
    function drawWeb() {
        ctx.clearRect(0, 0, webCanvas.width, webCanvas.height);
        
        // Update points
        points.forEach(point => {
            point.x += point.speedX;
            point.y += point.speedY;
            
            // Bounce off edges
            if (point.x < 0 || point.x > webCanvas.width) {
                point.speedX = -point.speedX;
            }
            if (point.y < 0 || point.y > webCanvas.height) {
                point.speedY = -point.speedY;
            }
        });
        
        // Draw connections
        points.forEach((point, i) => {
            points.forEach((otherPoint, j) => {
                if (i !== j) {
                    const dx = point.x - otherPoint.x;
                    const dy = point.y - otherPoint.y;
                    const distance = Math.sqrt(dx * dx + dy * dy);
                    
                    if (distance < 200) {
                        ctx.beginPath();
                        ctx.strokeStyle = `rgba(255, 255, 255, ${0.05 * (1 - distance / 200)})`;
                        ctx.lineWidth = 0.2;
                        ctx.moveTo(point.x, point.y);
                        ctx.lineTo(otherPoint.x, otherPoint.y);
                        ctx.stroke();
                    }
                }
            });
        });
        
        requestAnimationFrame(drawWeb);
    }
    
    drawWeb();
}